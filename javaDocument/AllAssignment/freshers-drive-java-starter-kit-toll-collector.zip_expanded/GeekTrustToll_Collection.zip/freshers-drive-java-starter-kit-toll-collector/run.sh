#!/bin/bash

javac src/Geektrust.java

java -cp ./src Geektrust sample_input/input1.txt
java -cp ./src Geektrust sample_input/input2.txt
java -cp ./src Geektrust sample_input/input3.txt
java -cp ./src Geektrust sample_input/input4.txt
java -cp ./src Geektrust sample_input/input5.txt